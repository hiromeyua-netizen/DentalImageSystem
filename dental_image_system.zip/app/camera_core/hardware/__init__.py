"""Hardware integration (Basler)."""
